# Virtual Classroom Project
The “Virtual Classroom” Website (web-based application) is useful for the students, faculty, guest whoever likes to learn from web using E-Learn (Videos), as well Check result, schedules of assessment and all that task like event, news, students can find out list of fresh courses offered by them and admission procedure, discussion forum, fee structure etc. without going to institute. It provides the facility to the students or guest to have complete information about the institute. In this application, the student can attend his\her missed classes from e-learn.

